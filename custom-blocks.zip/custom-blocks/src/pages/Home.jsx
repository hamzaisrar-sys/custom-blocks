import React from "react";
import {
  InputField,
  SelectField,
  CheckboxField,
  FormWrapper,
} from "../components/form";
import useFormValidation from "../hooks/useFormValidation";
import { validateForm } from "../utils/formValidators";
import Button from "../components/button/Button";

const Home = () => {
  const { values, errors, handleChange, handleSubmit } = useFormValidation(
    { name: "", email: "", gender: "", terms: false },
    validateForm
  );

  const submitForm = (formData) => {
    console.log("formData", formData);
  };

  return (
    <FormWrapper onSubmit={(e) => handleSubmit(e, submitForm)}>
      <InputField
        label="Name"
        name="name"
        value={values.name}
        onChange={handleChange}
      />
      {errors.name && <p className="error text-red-500">{errors.name}</p>}

      <InputField
        label="Email"
        type="email"
        name="email"
        value={values.email}
        onChange={handleChange}
      />
      {errors.email && <p className="error text-red-500">{errors.email}</p>}

      <SelectField
        label="Gender"
        name="gender"
        options={[
          { value: "male", label: "Male" },
          { value: "female", label: "Female" },
        ]}
        value={values.gender}
        onChange={handleChange}
      />

      <Button variant="primary" type="submit">
        Submit
      </Button>
    </FormWrapper>
  );
};

export default Home;
