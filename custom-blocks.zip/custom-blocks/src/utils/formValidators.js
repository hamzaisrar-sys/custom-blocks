export const validateForm = (field, value) => {
  let error = "";

  switch (field) {
    case "name":
      if (!value.trim()) error = "Name is required";
      break;
    case "email":
      if (!value) error = "Email is required";
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))
        error = "Invalid email format";
      break;
    case "terms":
      if (!value) error = "You must accept the terms";
      break;
    default:
      break;
  }

  return error;
};
