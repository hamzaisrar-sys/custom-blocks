const blockData = [
  { id: "1", type: "text", content: "Welcome to the custom block system!" },
  { id: "2", type: "image", content: "https://via.placeholder.com/150" },
  { id: "3", type: "video", content: "https://sample-videos.com/video123.mp4" },
  { id: "4", type: "button", content: { label: "Click Me", onClick: () => alert("Button Clicked!") } },
  { id: "5", type: "quote", content: { text: "The best way to predict the future is to create it.", author: "Peter Drucker" } },
  { id: "6", type: "list", content: { items: [
      { id: "6-1", text: "Item 1" },
      { id: "6-2", text: "Item 2" },
      { id: "6-3", text: "Item 3" },
    ] } },
];

export default blockData;
