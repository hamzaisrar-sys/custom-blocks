import React from "react";
import styles from "./FormFields.module.scss";

const CheckboxField = ({ label, checked, onChange }) => {
  return (
    <div className={styles.checkboxGroup}>
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        className={styles.checkbox}
      />
      <label className={styles.label}>{label}</label>
    </div>
  );
};

export default CheckboxField;
