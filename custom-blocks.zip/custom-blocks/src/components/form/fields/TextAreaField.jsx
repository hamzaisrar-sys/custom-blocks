import React from "react";
import styles from "./FormFields.module.scss";

const TextAreaField = ({ label, value, onChange, placeholder }) => {
  return (
    <div className={styles.formGroup}>
      {label && <label className={styles.label}>{label}</label>}
      <textarea
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className={styles.textarea}
      ></textarea>
    </div>
  );
};

export default TextAreaField;
