import React from "react";
import styles from "./FormFields.module.scss";

const RadioButtonField = ({ label, name, value, checked, onChange }) => {
  return (
    <div className={styles.radioGroup}>
      <input
        type="radio"
        name={name}
        value={value}
        checked={checked}
        onChange={onChange}
        className={styles.radio}
      />
      <label className={styles.label}>{label}</label>
    </div>
  );
};

export default RadioButtonField;
