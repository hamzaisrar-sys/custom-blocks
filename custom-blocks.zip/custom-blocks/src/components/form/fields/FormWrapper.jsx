import React from "react";
import styles from "./FormFields.module.scss";

const FormWrapper = ({ children, onSubmit }) => {
  const handleSubmit = (e) => {
    e.preventDefault();
    if (onSubmit) {
      onSubmit();
    }
  };

  return (
    <form onSubmit={handleSubmit} className={styles.formWrapper}>
      {children}
    </form>
  );
};

export default FormWrapper;
