import React from "react";
import styles from "./FormFields.module.scss";

const SelectField = ({ label, options, value, onChange }) => {
  return (
    <div className={styles.formGroup}>
      {label && <label className={styles.label}>{label}</label>}
      <select value={value} onChange={onChange} className={styles.select}>
        <option value="">Select an option</option>
        {options.map((option, index) => (
          <option key={index} value={option.value}>
            {option.label}
          </option>
        ))}
      </select>
    </div>
  );
};

export default SelectField;
