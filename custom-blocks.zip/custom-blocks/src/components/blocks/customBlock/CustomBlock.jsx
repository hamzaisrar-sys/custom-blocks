import React from "react";
import TextBlock from "../textBlock/TextBlock";
import ImageBlock from "../imageBlock/ImageBlock";
import VideoBlock from "../videoBlock/VideoBlock";
import ButtonBlock from "../buttonBlock/ButtonBlock";
import QuoteBlock from "../quoteBlock/QuoteBlock";
import ListBlock from "../listBlock/ListBlock";
import styles from "./CustomBlock.module.scss";

const CustomBlock = ({ type, content }) => {
  const renderBlock = () => {
    switch (type) {
      case "text":
        return <TextBlock text={content} />;
      case "image":
        return <ImageBlock src={content} />;
      case "video":
        return <VideoBlock src={content} />;
      case "button":
        return <ButtonBlock label={content.label} onClick={content.onClick} />;
      case "quote":
        return <QuoteBlock text={content.text} author={content.author} />;
      case "list":
        return <ListBlock items={content.items} />;
      default:
        return <p>Unsupported block type</p>;
    }
  };

  return <div className={styles.blockWrapper}>{renderBlock()}</div>;
};

export default CustomBlock;
