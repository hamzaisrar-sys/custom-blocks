import React from "react";
import styles from "./ListBlock.module.scss";

const ListBlock = ({ items }) => {
  return (
    <ul className={styles.list}>
      {items.map((item, index) => (
        <li key={index}>{item.text}</li>
      ))}
    </ul>
  );
};

export default ListBlock;
