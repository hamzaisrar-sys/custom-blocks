import React from "react";
import styles from "./ButtonBlock.module.scss";

const ButtonBlock = ({ label, onClick }) => {
  return (
    <button className={styles.button} onClick={onClick}>
      {label}
    </button>
  );
};

export default ButtonBlock;
