import React from "react";
import styles from "./QuoteBlock.module.scss";

const QuoteBlock = ({ text, author }) => {
  return (
    <blockquote className={styles.quote}>
      "{text}" <span>- {author}</span>
    </blockquote>
  );
};

export default QuoteBlock;
