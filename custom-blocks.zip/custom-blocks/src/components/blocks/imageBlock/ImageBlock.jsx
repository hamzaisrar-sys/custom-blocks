import React from "react";
import styles from "./ImageBlock.module.scss";

const ImageBlock = ({ src, alt }) => {
  return (
    <div className={styles.imageContainer}>
      <img className={styles.image} src={src} alt={alt} />
    </div>
  );
};

export default ImageBlock;
