import React from "react";
import { BlockProvider } from "./context/BlockContext";

const App = () => {
  return (
    <BlockProvider>
      <h1 className="text-black font-bold text-center">Custom Blocks</h1>
    </BlockProvider>
  );
};

export default App;
