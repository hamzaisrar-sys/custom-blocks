import React from "react";
import { DndContext, useDraggable, useDroppable } from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
} from "@dnd-kit/sortable";
import CustomBlock from "../components/blocks/customBlock/CustomBlock";
import useBlocks from "../hooks/useBlocks";
import styles from "./DragDropEditor.module.scss";

const DragDropEditor = () => {
  const { blocks, setBlocks } = useBlocks();

  const handleDragEnd = (event) => {
    const { active, over } = event;

    // ✅ Ensure both `active` and `over` exist before accessing their IDs
    if (!active || !over) return;

    if (active.id !== over.id) {
      const oldIndex = blocks.findIndex((b) => b.id === active.id);
      const newIndex = blocks.findIndex((b) => b.id === over.id);

      // ✅ Ensure valid indexes before updating state
      if (oldIndex !== -1 && newIndex !== -1) {
        setBlocks(arrayMove(blocks, oldIndex, newIndex));
      }
    }
  };

  return (
    <DndContext onDragEnd={handleDragEnd}>
      <SortableContext items={blocks.map((block) => block.id)}>
        <div className={styles.editor}>
          {blocks.map((block) => (
            <DraggableBlock key={block.id} block={block} />
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
};

const DraggableBlock = ({ block }) => {
  const { attributes, listeners, setNodeRef, transform } = useDraggable({
    id: block.id,
  });

  return (
    <div
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      className={styles.draggable}
    >
      <CustomBlock type={block.type} content={block.content} />
    </div>
  );
};

export default DragDropEditor;
