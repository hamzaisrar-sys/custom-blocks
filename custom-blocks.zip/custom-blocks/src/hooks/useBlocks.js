import { useState, useEffect } from "react";
import blockData from "../utils/blockData"
const useBlocks = () => {
    const [blocks, setBlocks] = useState(blockData);
    
  const addBlock = (type, content) => {
    const newBlock = {
      id: Date.now(),
      type,
      content,
    };
    setBlocks((prevBlocks) => [...prevBlocks, newBlock]);
  };

  // Remove a block by ID
  const removeBlock = (id) => {
    setBlocks((prevBlocks) => prevBlocks.filter((block) => block.id !== id));
  };

  // Reorder blocks
  const moveBlock = (fromIndex, toIndex) => {
    setBlocks((prevBlocks) => {
      const updatedBlocks = [...prevBlocks];
      const [movedBlock] = updatedBlocks.splice(fromIndex, 1);
      updatedBlocks.splice(toIndex, 0, movedBlock);
      return updatedBlocks;
    });
  };

  // Edit a block's content
  const updateBlock = (id, newContent) => {
    setBlocks((prevBlocks) =>
      prevBlocks.map((block) =>
        block.id === id ? { ...block, content: newContent } : block
      )
    );
  };

  return { blocks, addBlock, removeBlock, moveBlock, updateBlock };
};

export default useBlocks;
