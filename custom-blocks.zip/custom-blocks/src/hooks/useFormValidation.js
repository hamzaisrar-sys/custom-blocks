import { useState } from "react";

const useFormValidation = (initialValues, validate) => {
  const [values, setValues] = useState(initialValues);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    
    setValues((prevValues) => ({
      ...prevValues,
      [name]: type === "checkbox" ? checked : value,
    }));

    // Validate on change and clear error if valid
    setErrors((prevErrors) => ({
      ...prevErrors,
      [name]: validate ? validate(name, value) : "",
    }));
  };

  const handleSubmit = (e, callback) => { 
    if (e && e.preventDefault) {
      e.preventDefault(); 
    }

    const validationErrors = {};
    Object.keys(values).forEach((field) => {
      const error = validate(field, values[field]);
      if (error) validationErrors[field] = error;
    });

    setErrors(validationErrors);

    if (Object.keys(validationErrors).length === 0) {
      setIsSubmitting(true);
      callback(values);
      setIsSubmitting(false);
    }
  };

  return { values, errors, handleChange, handleSubmit };
};

export default useFormValidation;
