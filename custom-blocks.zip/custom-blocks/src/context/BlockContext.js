import React, { createContext, useState, useEffect } from "react";
import blockData from "../utils/blockData";

export const BlockContext = createContext();

export const BlockProvider = ({ children }) => {
  const [blocks, setBlocks] = useState(blockData);

  return (
    <BlockContext.Provider value={{ blocks, setBlocks }}>
      {children}
    </BlockContext.Provider>
  );
};
